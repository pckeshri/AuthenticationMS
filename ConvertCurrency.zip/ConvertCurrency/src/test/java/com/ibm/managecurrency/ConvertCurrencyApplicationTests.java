package com.ibm.managecurrency;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConvertCurrencyApplicationTests {

	@Test
	void contextLoads() {
	}

}
