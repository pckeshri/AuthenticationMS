package com.ibm.order.helper;

import java.util.Date;
import java.util.List;
import java.util.function.Function;

import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;

@Component
public class OrderJWTHelper {

	private final String PREFIX = "Bearer ";
	private final String SECRET = "hakunamatata";

	public boolean validateToken(String token) {
		System.out.println("in validate token");

		Claims claims = getClaim(token);
		if (claims.get("authorities") != null) {
			return authenticateClaim(claims);
		} else {
			return false;
		}

		// add the moment return just true

		// return true;

	}

	private Claims getClaim(String token) throws ExpiredJwtException {
		return Jwts.parser().setSigningKey(SECRET.getBytes()).parseClaimsJws(token.replace(PREFIX, "")).getBody();
	}

	/**
	 * Authentication method in Spring flow
	 * 
	 * @param claims
	 */
	private boolean authenticateClaim(Claims claims) {
		@SuppressWarnings("unchecked")
		List<String> authorities = (List<String>) claims.get("authorities");
		if (authorities != null)
			return true;
		else
			return false;

	}

	// check if the token has expired

	public Boolean isTokenExpired(String token)  throws ExpiredJwtException{

		final Date expiration = getExpirationDateFromToken(token);

		return expiration.before(new Date());

	}

	// retrieve expiration date from jwt token

	public Date getExpirationDateFromToken(String token) throws ExpiredJwtException {

		return getClaimFromToken(token, Claims::getExpiration);

	}

	public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) throws ExpiredJwtException {

		final Claims claims = getClaim(token);

		return claimsResolver.apply(claims);

	}

}
