package com.ibm.order.dao;

import org.springframework.data.repository.CrudRepository;

public interface OrderDAO extends CrudRepository<OrderDTO,String>{

}
