package com.ibm.order.controller;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ibm.order.dao.OrderDAO;
import com.ibm.order.dao.OrderDTO;
import com.ibm.order.helper.OrderJWTHelper;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Controller
public class OrderController {

	@Autowired
	OrderJWTHelper jwtHelper;
	
	@Autowired
	OrderDAO orderDAO;

	@GetMapping("placeorder")
	public String displayOrderPage(HttpServletRequest req, HttpServletResponse res) {
		
		String jwtToken = req.getParameter("jwtToken");
		System.out.println("in the orderorder service and token is " + jwtToken);
		
		if(jwtToken == null )
		{
			//return to error page or do something.
		    return "error.jsp";

		}

//		if (jwtHelper.validateToken(jwtToken))
//			return "home.jsp";
//		else 
//			return "error.jsp";
		
		req.setAttribute("TTLTOKEN", getTTLToken());

		return "home.jsp";
	}
	
	@RequestMapping("addOrder")
	public String addOrder(String TTL,String orderDetails) {
		System.out.println("in endpoint addorder" + TTL);
		try {
			if(!jwtHelper.isTokenExpired(TTL))
			{
				OrderDTO dto = new OrderDTO();
				dto.setOrderDetails(orderDetails);
				dto.setTtl(TTL);
				orderDAO.save(dto);
				System.out.println("data saved to DB");
			}
				
			//System.out.println("check status "+ jwtHelper.isTokenExpired(TTL));
		}catch (ExpiredJwtException e) {
			System.out.println("unsuccessful and show error page");
			return "error.jsp";
		}
		
		
		return "success.jsp";
	}

	// generates JWT
	private String getTTLToken() {
		String secretKey = "hakunamatata";
		List<GrantedAuthority> grantedAuthorities = AuthorityUtils.commaSeparatedStringToAuthorityList("ROLE_USER");

		String token = Jwts.builder().setId("logintoken").setSubject("Order")
				.claim("authorities",
						grantedAuthorities.stream().map(GrantedAuthority::getAuthority).collect(Collectors.toList()))
				.setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + 120000))
				.signWith(SignatureAlgorithm.HS512, secretKey.getBytes()).compact();

		return "Bearer " + token;
	}

}
