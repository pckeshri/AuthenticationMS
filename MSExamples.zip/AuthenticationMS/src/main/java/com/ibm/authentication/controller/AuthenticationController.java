package com.ibm.authentication.controller;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@EnableFeignClients
@RestController
public class AuthenticationController {
	
	@Autowired
	private OrderFeignClient orderClient;
	
	private final String HEADER = "Authorization";
	
	@GetMapping("/usercheck")
	public ModelAndView authenticateUser(HttpServletRequest request,HttpServletResponse response) {
		
		ModelAndView mv = new ModelAndView();
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String strJWTtoken = null;
		System.out.println("endpoint userchecking");
		
		if(username.startsWith("a"))
		{
			strJWTtoken = getJWTToken(username);
			
		}
		mv.addObject("jwtToken",strJWTtoken);
		mv.setViewName("home.jsp");
		return mv;
		
	}
	
	
//	@RequestMapping("/callOrder")
//	public void callOrderService(String strJWTtoken)
//	{
//		orderClient.clientResponse(strJWTtoken);
//	}
	
//	//just to verify that call to this endpoint should throw access denied error.
//	@GetMapping("/Checkother")
//	public void callOtherService() {
//		
//		System.out.println("endpoint Checkother");
//		
//	}
	
	//generates JWT 
	private String getJWTToken(String username) {
		String secretKey = "hakunamatata";
		List<GrantedAuthority> grantedAuthorities = AuthorityUtils
				.commaSeparatedStringToAuthorityList("ROLE_USER");
		
		String token = Jwts
				.builder()
				.setId("logintoken")
				.setSubject(username)
				.claim("authorities",
						grantedAuthorities.stream()
								.map(GrantedAuthority::getAuthority)
								.collect(Collectors.toList()))
				.setIssuedAt(new Date(System.currentTimeMillis()))
				//.setExpiration(new Date(System.currentTimeMillis() + 600000))
				.signWith(SignatureAlgorithm.HS512,
						secretKey.getBytes()).compact();

		return "Bearer " + token;
	}

}
