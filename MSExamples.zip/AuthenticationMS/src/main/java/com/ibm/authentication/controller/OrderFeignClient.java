package com.ibm.authentication.controller;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(value="OrderService", url="http://localhost:8081")
public interface OrderFeignClient {
	
	@GetMapping("/placeorder")
	void clientResponse(@RequestParam(name = "jwtToken") String jwtToken);

}
